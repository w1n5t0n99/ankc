This game was made by Matt Thorson.

It is freeware, so you can share it with your friends.

However, you may not host it on the internet, you may only 
link to it at my site (http://www.mattmakesgames.com/), and
if distributed by other means, this readme file must be with
it.

Also, it would be greatly appreciated if you spread the word about
my games in any way you can, especially if you're linking to them
from another site.

Matt Makes Games
http://www.mattmakesgames.com/